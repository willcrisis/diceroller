self.__precacheManifest = [
  {
    "revision": "35297c57240811b8f2e9",
    "url": "/diceroller/static/js/app.469d8a0f.chunk.js"
  },
  {
    "revision": "54cdd124c50c9b5ca476",
    "url": "/diceroller/static/js/runtime~app.df419897.js"
  },
  {
    "revision": "382a773c1502835ad1ba",
    "url": "/diceroller/static/js/2.5ae0b61a.chunk.js"
  },
  {
    "revision": "6165c9d7a2e729ba57b23dd93add5366",
    "url": "/diceroller/static/media/back-icon-mask.6165c9d7.png"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/diceroller/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/diceroller/./fonts/Ionicons.ttf"
  },
  {
    "revision": "761a29cc5b9163dd2a23118c3d85605d",
    "url": "/diceroller/static/media/expo-icon.761a29cc.png"
  },
  {
    "revision": "54da1e9816c77e30ebc5920e256736f2",
    "url": "/diceroller/static/media/robot-dev.54da1e98.png"
  },
  {
    "revision": "c7578911196974808febf223f05a8364",
    "url": "/diceroller/static/media/robot-prod.c7578911.png"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/diceroller/./fonts/AntDesign.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/diceroller/./fonts/Entypo.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/diceroller/./fonts/Feather.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/diceroller/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/diceroller/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/diceroller/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/diceroller/./fonts/Foundation.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/diceroller/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/diceroller/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/diceroller/serve.json"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/diceroller/favicon.ico"
  },
  {
    "revision": "5e695e96a003a79f7f97060bf49409a9",
    "url": "/diceroller/expo-service-worker.js"
  },
  {
    "revision": "5311016f5b0933c6cdf92326defeffb9",
    "url": "/diceroller/manifest.json"
  },
  {
    "revision": "e0ea48ed76c881fad684ea2a7c75eb93",
    "url": "/diceroller/index.html"
  }
];